package fule.com.mywheelview.bean;


import java.io.Serializable;

public class AddressModel implements Serializable {
    public int Status;
    public String Msg;
    public AddressDetailsEntity Result;
    public String ServerTime;
}
