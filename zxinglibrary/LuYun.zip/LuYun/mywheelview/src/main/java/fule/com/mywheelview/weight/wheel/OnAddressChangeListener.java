package fule.com.mywheelview.weight.wheel;

public interface OnAddressChangeListener {
	void onAddressChange(String province, String city, String district);
}
