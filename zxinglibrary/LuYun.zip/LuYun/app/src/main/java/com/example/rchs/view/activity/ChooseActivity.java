package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class ChooseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(ChooseActivity.this,true);
        StatusBarUtil.setTranslucentStatus(ChooseActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(ChooseActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(ChooseActivity.this,0x55000000);
        }

        Button add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChooseActivity.this,AddCodeActivity.class);
                startActivity(intent);
            }
        });
    }
}
