package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class T_QueryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t__query);
        StatusBarUtil.setRootViewFitsSystemWindows(T_QueryActivity.this,true);
        StatusBarUtil.setTranslucentStatus(T_QueryActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(T_QueryActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(T_QueryActivity.this,0x55000000);
        }
    }
}
