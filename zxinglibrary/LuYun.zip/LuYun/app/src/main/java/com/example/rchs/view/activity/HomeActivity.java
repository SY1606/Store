package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;
import com.example.rchs.view.fragment.Frag_bill;
import com.example.rchs.view.fragment.Frag_gather;
import com.example.rchs.view.fragment.Frag_guest;
import com.example.rchs.view.fragment.Frag_set;

public class HomeActivity extends AppCompatActivity {

    private RadioButton gather;
    private RadioButton bill;
    private RadioButton guest;
    private RadioButton set;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(HomeActivity.this,true);
        StatusBarUtil.setTranslucentStatus(HomeActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(HomeActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(HomeActivity.this,0x55000000);
        }


        gather = findViewById(R.id.gather);
        bill = findViewById(R.id.bill);
        guest = findViewById(R.id.guest);
        set = findViewById(R.id.set);

        final FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
      final Frag_gather frag_gather = new Frag_gather();
        final Frag_bill frag_bill = new Frag_bill();
        final Frag_guest frag_guest = new Frag_guest();
        final Frag_set frag_set = new Frag_set();
        transaction.add(R.id.mframe, frag_gather);
        transaction.add(R.id.mframe, frag_bill);
        transaction.add(R.id.mframe, frag_guest);
        transaction.add(R.id.mframe, frag_set);
        transaction.show(frag_gather);
        transaction.hide(frag_bill);
        transaction.hide(frag_guest);
        transaction.hide(frag_set);

        transaction.commit();
        //默认选中第一个
        RadioGroup rg = findViewById(R.id.rg);
        rg.check(rg.getChildAt(0).getId());

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                FragmentTransaction transaction1 = manager.beginTransaction();
                switch (i){
                    case R.id.gather:
                        transaction1.show(frag_gather).hide(frag_bill).hide(frag_guest).hide(frag_set);
                        break;
                    case R.id.bill:
                        transaction1.show(frag_bill).hide(frag_gather).hide(frag_guest).hide(frag_set);
                        break;
                    case R.id.guest:
                        transaction1.show(frag_guest).hide(frag_bill).hide(frag_gather).hide(frag_set);
                        break;
                    case R.id.set:
                        transaction1.show(frag_set).hide(frag_bill).hide(frag_guest).hide(frag_gather);
                        break;
                }
                transaction1.commit();
            }
        });
    }
}
