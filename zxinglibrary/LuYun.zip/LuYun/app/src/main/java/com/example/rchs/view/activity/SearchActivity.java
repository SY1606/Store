package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(SearchActivity.this,true);
        StatusBarUtil.setTranslucentStatus(SearchActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(SearchActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(SearchActivity.this,0x55000000);
        }
    }
}
