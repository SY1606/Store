package com.example.rchs.view.activity_bill;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.RadioGroup;

import com.example.rchs.R;
import com.example.rchs.view.fragment_two.Frag_all;
import com.example.rchs.view.fragment_two.Frag_dai;
import com.example.rchs.view.fragment_two.Frag_s_all;
import com.example.rchs.view.fragment_two.Frag_s_pay;
import com.example.rchs.view.fragment_two.Frag_s_tui;
import com.example.rchs.view.fragment_two.Frag_s_wei;
import com.example.rchs.view.fragment_two.Frag_you;
import com.example.rchs.view.fragment_two.Frag_zhe;

public class ShaiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shai);

        final FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        final Frag_s_all frag_s_all = new Frag_s_all();
        final Frag_s_wei frag_s_wei= new Frag_s_wei();
        final Frag_s_pay frag_s_pay = new Frag_s_pay();
        final Frag_s_tui frag_s_tui = new Frag_s_tui();
        transaction.add(R.id.frag_myfocus,frag_s_all);
        transaction.add(R.id.frag_myfocus,frag_s_wei);
        transaction.add(R.id.frag_myfocus,frag_s_pay);
        transaction.add(R.id.frag_myfocus,frag_s_tui);
        transaction.show(frag_s_all).hide(frag_s_wei).hide(frag_s_pay).hide(frag_s_tui);
        transaction.commit();

        RadioGroup rg_focus = findViewById(R.id.rg_focus);
        rg_focus.check(R.id.a11);
        rg_focus.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                FragmentTransaction transaction1 = manager.beginTransaction();
                switch (checkedId){
                    case R.id.a11:
                        transaction1.show(frag_s_all).hide(frag_s_wei).hide(frag_s_pay).hide(frag_s_tui);
                        break;
                    case R.id.pay:
                        transaction1.show(frag_s_pay).hide(frag_s_all).hide(frag_s_wei).hide(frag_s_tui);
                        break;
                    case R.id.weixin:
                        transaction1.show(frag_s_wei).hide(frag_s_all).hide(frag_s_pay).hide(frag_s_tui);
                        break;
                    case R.id.tui:
                        transaction1.show(frag_s_tui).hide(frag_s_wei).hide(frag_s_all).hide(frag_s_pay);
                        break;
                }
                transaction1.commit();
            }
        });
    }
}
