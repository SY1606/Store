package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class EditorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(EditorActivity.this,true);
        StatusBarUtil.setTranslucentStatus(EditorActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(EditorActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(EditorActivity.this,0x55000000);
        }
    }
}
