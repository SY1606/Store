package com.example.rchs.view.activity_guest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.HorizontalBarView;

import java.util.ArrayList;

public class MoneyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money);
        HorizontalBarView horizontalbar = (HorizontalBarView)findViewById(R.id.horizontalbar);
        ArrayList<HorizontalBarView.HoBarEntity> hoBarEntities = new ArrayList<>();
        HorizontalBarView.HoBarEntity hoBarEntity = new HorizontalBarView.HoBarEntity();
        hoBarEntity.content = "嗯啦";
        hoBarEntity.count = 12;
        hoBarEntities.add(hoBarEntity);
        HorizontalBarView.HoBarEntity hoBarEntity1 = new HorizontalBarView.HoBarEntity();
        hoBarEntity1.content = "啦额";
        hoBarEntity1.count = 72;
        hoBarEntities.add(hoBarEntity1);
        HorizontalBarView.HoBarEntity hoBarEntity2 = new HorizontalBarView.HoBarEntity();
        hoBarEntity2.content = "啦啦嗯嗯啦";
        hoBarEntity2.count = 25;
        hoBarEntities.add(hoBarEntity2);
        HorizontalBarView.HoBarEntity hoBarEntity3 = new HorizontalBarView.HoBarEntity();
        hoBarEntity3.content = "啦e啦ee啦";
        hoBarEntity3.count = 120;
        hoBarEntities.add(hoBarEntity3);
        horizontalbar.setHoBarData(hoBarEntities);

    }
}
