package com.example.rchs.di.contract;

import okhttp3.MultipartBody;

public interface DatasContract {
    public interface DatasView{
        public void showPhotoData(String message);
    }

    public interface DatasPresenter<PhotoView>{
        public void attachView(PhotoView photoView);
        public void detachView(PhotoView photoView);

        public void requestPhotoData(MultipartBody.Part image);
    }

    public interface DatasModel{
        public void reponsePhotoData(MultipartBody.Part image, CallBack callBack);

        public interface CallBack{
            public void onCallBack(String message);
        }
    }
}
