package com.example.rchs.view.fragment_two;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.rchs.R;
import com.example.rchs.view.activity_set.ChooseStoreActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class Frag_s_all extends Fragment {

    @BindView(R.id.start_time)
    Button startTime;
    @BindView(R.id.starts_time)
    Button startsTime;
    @BindView(R.id.end_time)
    Button endTime;
    @BindView(R.id.ends_time)
    Button endsTime;
    @BindView(R.id.chooes)
    RelativeLayout chooes;

    private Dialog dateDialog, timeDialog, chooseDialog;
    private TextView mTextView;
    private List<String> list = new ArrayList<>();
    //private ChooseAddressWheel chooseAddressWheel;
    private String address;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_s_all, container, false);

        return view;
    }

    @OnClick({R.id.start_time, R.id.starts_time, R.id.end_time, R.id.ends_time, R.id.chooes})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.start_time:

                break;
            case R.id.starts_time:

                break;
            case R.id.end_time:

                break;
            case R.id.ends_time:

                break;
            case R.id.chooes:
                Intent intent = new Intent(getActivity(), ChooseStoreActivity.class);
                startActivity(intent);
                break;
        }
    }
}
