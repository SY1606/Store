package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class AddCodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_code);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(AddCodeActivity.this,true);
        StatusBarUtil.setTranslucentStatus(AddCodeActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(AddCodeActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(AddCodeActivity.this,0x55000000);
        }
    }
}
