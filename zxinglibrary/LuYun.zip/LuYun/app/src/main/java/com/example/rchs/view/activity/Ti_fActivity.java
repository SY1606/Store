package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class Ti_fActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ti_f);
        StatusBarUtil.setRootViewFitsSystemWindows(Ti_fActivity.this,true);
        StatusBarUtil.setTranslucentStatus(Ti_fActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(Ti_fActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(Ti_fActivity.this,0x55000000);
        }
    }
}
