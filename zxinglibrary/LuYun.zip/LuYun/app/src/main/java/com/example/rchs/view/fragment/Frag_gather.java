package com.example.rchs.view.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.rchs.R;
import com.example.rchs.view.activity.ChongActivity;
import com.example.rchs.view.activity.ConsumeActivity;
import com.example.rchs.view.activity.DiscountListActivity;
import com.example.rchs.view.activity.FixedActivity;
import com.example.rchs.view.activity.HexiaoActivity;
import com.example.rchs.view.activity.MemListActivity;
import com.example.rchs.view.activity.NewDiscountActivity;
import com.example.rchs.view.activity.SacnActivity;
import com.example.rchs.view.activity.SelfActivity;
import com.facebook.drawee.view.SimpleDraweeView;
import com.youth.banner.Banner;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class Frag_gather extends Fragment {

    @BindView(R.id.scan)
    ImageView scan;
    @BindView(R.id.gd)
    ImageView gd;
    @BindView(R.id.tui)
    TextView tui;
    @BindView(R.id.t_m)
    TextView tM;
    @BindView(R.id.shi)
    TextView shi;
    @BindView(R.id.s_m)
    TextView sM;
    @BindView(R.id.Nm)
    TextView Nm;
    @BindView(R.id.send)
    TextView send;
    @BindView(R.id.chong)
    TextView chong;
    @BindView(R.id.n_m)
    TextView nM;
    @BindView(R.id.send_m)
    TextView sendM;
    @BindView(R.id.c_m)
    TextView cM;
    @BindView(R.id.banner)
    Banner banner;
    @BindView(R.id.member)
    TextView member;
    @BindView(R.id.sim_x)
    SimpleDraweeView simC;
    @BindView(R.id.sim_l)
    SimpleDraweeView simL;
    @BindView(R.id.sim_s)
    SimpleDraweeView simS;
    @BindView(R.id.x)
    TextView x;
    @BindView(R.id.l)
    TextView l;
    @BindView(R.id.s)
    TextView s;
    @BindView(R.id.sim_h)
    SimpleDraweeView simH;
    @BindView(R.id.sim_y)
    SimpleDraweeView simY;
    @BindView(R.id.sim_z)
    SimpleDraweeView simZ;
    @BindView(R.id.h)
    TextView h;
    @BindView(R.id.y)
    TextView y;
    @BindView(R.id.z)
    TextView z;
    @BindView(R.id.self)
    ImageView self;
    @BindView(R.id.jiao)
    TextView jiao;
    @BindView(R.id.j_m)
    TextView jM;
    private Unbinder unbinder;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_gather, container, false);
        unbinder = ButterKnife.bind(this, view);

        if (savedInstanceState != null) {
            // FRAGMENTS_TAG
            savedInstanceState.remove("android:support:fragments");
            savedInstanceState.remove("android:fragments");
        }
        super.onCreate(savedInstanceState);

        return view;
    }

    @OnClick({R.id.scan, R.id.gd, R.id.sim_x, R.id.sim_l, R.id.sim_s, R.id.sim_h, R.id.sim_y, R.id.sim_z,R.id.jiao,R.id.j_m,R.id.self})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            //扫码收款
            case R.id.scan:
                Intent intent = new Intent(getActivity(), SacnActivity.class);
                startActivity(intent);
                break;
                //自动收款
            case R.id.self:
                Intent intent1 = new Intent(getActivity(), SelfActivity.class);
                startActivity(intent1);
                break;
                //固定收款码
            case R.id.gd:
                Intent intent2 = new Intent(getActivity(), FixedActivity.class);
                startActivity(intent2);
                break;
                //消费
            case R.id.sim_x:
                Intent intent3 = new Intent(getActivity(), ConsumeActivity.class);
                startActivity(intent3);
                break;
                //充值
            //case R.id.sim_c:
                //Intent intent4 = new Intent(getActivity(), ChongActivity.class);
                //startActivity(intent4);
                //break;
                //会员列表
            case R.id.sim_l:
                Intent intent5 = new Intent(getActivity(), MemListActivity.class);
                startActivity(intent5);
                break;
                //扫码开卡
            case R.id.sim_s:

                break;
                //优惠卡核销
            case R.id.sim_h:
                Intent intent7 = new Intent(getActivity(), HexiaoActivity.class);
                startActivity(intent7);
                break;
                //优惠券列表
            case R.id.sim_y:
                Intent intent8 = new Intent(getActivity(), DiscountListActivity.class);
                startActivity(intent8);
                break;
                //优惠券新增
            case R.id.sim_z:
                Intent intent9 = new Intent(getActivity(), NewDiscountActivity.class);
                startActivity(intent9);
                break;
        }
    }
}
