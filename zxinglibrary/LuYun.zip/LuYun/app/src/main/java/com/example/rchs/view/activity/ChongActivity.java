package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class ChongActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chong);
        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(ChongActivity.this,true);
        StatusBarUtil.setTranslucentStatus(ChongActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(ChongActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(ChongActivity.this,0x55000000);
        }
    }
}
