package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class DeleteCodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emplie);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(DeleteCodeActivity.this,true);
        StatusBarUtil.setTranslucentStatus(DeleteCodeActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(DeleteCodeActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(DeleteCodeActivity.this,0x55000000);
        }
    }
}
