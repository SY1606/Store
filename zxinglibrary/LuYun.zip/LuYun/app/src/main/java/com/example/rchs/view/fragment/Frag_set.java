package com.example.rchs.view.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.rchs.R;
import com.example.rchs.view.activity_set.ChooseStoreActivity;
import com.example.rchs.view.activity_set.UpdatePwdActivity;
import com.facebook.drawee.view.SimpleDraweeView;

import butterknife.BindView;
import butterknife.OnClick;

public class Frag_set extends Fragment {

    @BindView(R.id.msimple)
    SimpleDraweeView msimple;
    @BindView(R.id.mtext_name)
    TextView mtextName;
    @BindView(R.id.mtext_qian)
    TextView mtextQian;
    @BindView(R.id.image_capacity)
    ImageView imageCapacity;
    @BindView(R.id.text_capacity)
    TextView textCapacity;
    @BindView(R.id.choose)
    TextView choose;
    @BindView(R.id.image_sound)
    ImageView imageSound;
    @BindView(R.id.text_sound)
    TextView textSound;
    @BindView(R.id.views)
    View views;
    @BindView(R.id.image_tui)
    ImageView imageTui;
    @BindView(R.id.text_tui)
    TextView textTui;
    @BindView(R.id.image_update)
    ImageView imageUpdate;
    @BindView(R.id.text_update)
    TextView textUpdate;
    @BindView(R.id.image_qing)
    ImageView imageQing;
    @BindView(R.id.text_qing)
    TextView textQing;
    @BindView(R.id.tuichu)
    Button tuichu;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_set, container, false);

        RelativeLayout update = view.findViewById(R.id.update);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), UpdatePwdActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }

    @OnClick({R.id.choose, R.id.tuichu})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.choose:
                Intent intent = new Intent(getActivity(), ChooseStoreActivity.class);
                startActivity(intent);
                break;
            case R.id.tuichu:
                break;
        }
    }
}
