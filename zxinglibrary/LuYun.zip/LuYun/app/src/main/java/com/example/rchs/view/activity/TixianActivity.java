package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class TixianActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tixian);
        StatusBarUtil.setRootViewFitsSystemWindows(TixianActivity.this,true);
        StatusBarUtil.setTranslucentStatus(TixianActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(TixianActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(TixianActivity.this,0x55000000);
        }
    }
}
