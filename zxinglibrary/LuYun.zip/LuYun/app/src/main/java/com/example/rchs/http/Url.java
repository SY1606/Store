package com.example.rchs.http;

public class Url {
    public static final String WAI_URL = "";
}
