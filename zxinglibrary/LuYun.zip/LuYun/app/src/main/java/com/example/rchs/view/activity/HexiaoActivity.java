package com.example.rchs.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HexiaoActivity extends AppCompatActivity {

    @BindView(R.id.mingxi)
    TextView mingxi;
    @BindView(R.id.money)
    EditText money;
    @BindView(R.id.code)
    TextView code;
    @BindView(R.id.hexiao)
    EditText hexiao;
    @BindView(R.id.view10)
    View view10;
    @BindView(R.id.sao)
    Button sao;
    @BindView(R.id.queding)
    Button queding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hexiao);
        ButterKnife.bind(this);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(HexiaoActivity.this, true);
        StatusBarUtil.setTranslucentStatus(HexiaoActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(HexiaoActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(HexiaoActivity.this, 0x55000000);
        }
    }

    @OnClick({R.id.mingxi, R.id.hexiao, R.id.sao, R.id.queding})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.mingxi:
                Intent intent = new Intent(HexiaoActivity.this,MingXiActivity.class);
                startActivity(intent);
                break;
            case R.id.hexiao:

                break;
            case R.id.sao:
                break;
            case R.id.queding:
                break;
        }
    }
}
