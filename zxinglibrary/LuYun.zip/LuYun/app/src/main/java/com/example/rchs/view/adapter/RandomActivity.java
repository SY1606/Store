package com.example.rchs.view.adapter;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.rchs.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xuejinwei on 16/8/19.
 * Email:xuejinwei@outlook.com
 */
public class RandomActivity extends AppCompatActivity {

    @BindView(R.id.et_rondom)
    EditText etRondom;
    @BindView(R.id.keyboard_view)
    MyKeyBoardView keyboardView;
    private KeyboardUtil keyboardUtil;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random);
        ButterKnife.bind(this);
        keyboardUtil = new KeyboardUtil(RandomActivity.this, true);

        etRondom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyboardUtil.attachTo(etRondom);
            }
        });
    }
}
