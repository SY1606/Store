package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class RecordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(RecordActivity.this,true);
        StatusBarUtil.setTranslucentStatus(RecordActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(RecordActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(RecordActivity.this,0x55000000);
        }
    }
}
