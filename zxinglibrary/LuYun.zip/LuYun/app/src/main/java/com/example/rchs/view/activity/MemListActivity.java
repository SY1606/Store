package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class MemListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mem_list);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(MemListActivity.this,true);
        StatusBarUtil.setTranslucentStatus(MemListActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(MemListActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(MemListActivity.this,0x55000000);
        }
        EditText search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MemListActivity.this,SearchActivity.class);
                startActivity(intent);
            }
        });
    }
}
