package com.example.rchs.view.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.rchs.R;
import com.example.rchs.view.activity_guest.GukeActivity;
import com.example.rchs.view.activity_guest.MoneyActivity;
import com.example.rchs.view.activity_guest.TimeActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class Frag_guest extends Fragment {

    @BindView(R.id.time)
    RelativeLayout time;
    @BindView(R.id.money)
    RelativeLayout money;
    @BindView(R.id.guke)
    RelativeLayout guke;
    private Unbinder unbinder;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_guest, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @OnClick({R.id.time, R.id.money, R.id.guke})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.time:
                Intent intent = new Intent(getActivity(), TimeActivity.class);
                startActivity(intent);
                break;
            case R.id.money:
                Intent intent1 = new Intent(getActivity(), MoneyActivity.class);
                startActivity(intent1);
                break;
            case R.id.guke:
                Intent intent2 = new Intent(getActivity(), GukeActivity.class);
                startActivity(intent2);
                break;
        }
    }
}
