package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;
import com.facebook.drawee.backends.pipeline.Fresco;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fresco.initialize(this);
        setContentView(R.layout.activity_login);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(LoginActivity.this,true);
        StatusBarUtil.setTranslucentStatus(LoginActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(LoginActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(LoginActivity.this,0x55000000);
        }

      Button mlogin = findViewById(R.id.mlogin);
        mlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}
