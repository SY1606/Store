package com.example.rchs.di.model;

import android.util.Log;

import com.example.rchs.di.contract.DatasContract;
import com.example.rchs.net.ApiService;
import com.example.rchs.net.Contant;
import com.example.rchs.net.RetrofitUtils;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MultipartBody;
import okhttp3.ResponseBody;

public class DatasModel implements DatasContract.DatasModel {

    @Override
    public void reponsePhotoData(MultipartBody.Part image, final CallBack callBack) {
        RetrofitUtils.getRetrofitUtils().getApiService(Contant.Re, ApiService.class)
                .getNewDisContent(image)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<ResponseBody>() {
                    @Override
                    public void accept(ResponseBody responseBody) throws Exception {
                        String response = responseBody.string();
                       callBack.onCallBack(response);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        String errorMsg = throwable.getMessage();
                        Log.i("Photo","失败:"+errorMsg);
                    }
                });
    }

}
