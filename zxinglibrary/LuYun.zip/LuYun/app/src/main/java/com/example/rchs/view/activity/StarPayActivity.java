package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class StarPayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_star_pay);
        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(StarPayActivity.this,true);
        StatusBarUtil.setTranslucentStatus(StarPayActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(StarPayActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(StarPayActivity.this,0x55000000);
        }
    }
}
