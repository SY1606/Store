package com.example.rchs.view.activity_bill;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;

public class RefundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund);
    }
}
