package com.example.rchs.view.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.rchs.R;
import com.example.rchs.view.activity.StarPayActivity;
import com.example.rchs.view.activity.StoreActivity;
import com.example.rchs.view.activity_bill.DalisListActivity;
import com.example.rchs.view.activity_bill.ShaiActivity;
import com.facebook.drawee.view.SimpleDraweeView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class Frag_bill extends Fragment {
    @BindView(R.id.rec_money)
    TextView recMoney;
    @BindView(R.id.r_money)
    TextView rMoney;
    @BindView(R.id.tr_number)
    TextView trNumber;
    @BindView(R.id.number)
    TextView number;
    @BindView(R.id.tr_money)
    TextView trMoney;
    @BindView(R.id.t_money)
    TextView tMoney;
    @BindView(R.id.tui_money)
    TextView tuiMoney;
    @BindView(R.id.tu_money)
    TextView tuMoney;
    @BindView(R.id.sim_dalisList)
    SimpleDraweeView simDalisList;
    @BindView(R.id.sim_refund)
    SimpleDraweeView simRefund;
    @BindView(R.id.sim_store)
    SimpleDraweeView simStore;
    @BindView(R.id.dalisList)
    TextView dalisList;
    @BindView(R.id.refund)
    TextView refund;
    @BindView(R.id.store)
    TextView store;
    @BindView(R.id.shai)
    TextView shai;
    private Unbinder unbinder;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_bill, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;


    }

    @OnClick({R.id.sim_dalisList, R.id.sim_refund, R.id.sim_store,R.id.shai})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            //日结清单
            case R.id.sim_dalisList:
                Intent intent = new Intent(getActivity(), DalisListActivity.class);
                startActivity(intent);
                break;
            //门店统计
            case R.id.sim_refund:
                Intent intent3 = new Intent(getActivity(), StoreActivity.class);
                startActivity(intent3);
                break;

            //星驿付
            case R.id.sim_store:
                Intent intent4 = new Intent(getActivity(), StarPayActivity.class);
                startActivity(intent4);
                break;
            //筛选
            case R.id.shai:
                Intent intent5 = new Intent(getActivity(), ShaiActivity.class);
                startActivity(intent5);
                break;

        }
    }
}
