package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class FixedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fixed);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(FixedActivity.this,true);
        StatusBarUtil.setTranslucentStatus(FixedActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(FixedActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(FixedActivity.this,0x55000000);
        }
    }
}
