package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;

public class Ti_SActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ti__s);
        StatusBarUtil.setRootViewFitsSystemWindows(Ti_SActivity.this,true);
        StatusBarUtil.setTranslucentStatus(Ti_SActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(Ti_SActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(Ti_SActivity.this,0x55000000);
        }
    }
}
