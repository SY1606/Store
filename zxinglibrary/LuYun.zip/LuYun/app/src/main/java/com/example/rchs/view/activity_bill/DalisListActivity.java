package com.example.rchs.view.activity_bill;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;
import com.example.rchs.view.activity.SacnActivity;

public class DalisListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dalis_list);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(DalisListActivity.this,true);
        StatusBarUtil.setTranslucentStatus(DalisListActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(DalisListActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(DalisListActivity.this,0x55000000);
        }

    }
}
