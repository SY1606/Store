package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.RadioGroup;

import com.example.rchs.R;
import com.example.rchs.view.frag_two.Frag01;
import com.example.rchs.view.frag_two.Frag02;
import com.example.rchs.view.frag_two.Frag03;
import com.example.rchs.view.frag_two.Frag04;
import com.example.rchs.view.fragment_two.Frag_all;
import com.example.rchs.view.fragment_two.Frag_dai;
import com.example.rchs.view.fragment_two.Frag_you;
import com.example.rchs.view.fragment_two.Frag_zhe;

public class DiscountListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount_list);

        final FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        final Frag01 frag01 = new Frag01();
        final Frag02 frag02 = new Frag02();
        final Frag03 frag03 = new Frag03();
        final Frag04 frag04 = new Frag04();
        transaction.add(R.id.frag_myfocus,frag01);
        transaction.add(R.id.frag_myfocus,frag02);
        transaction.add(R.id.frag_myfocus,frag03);
        transaction.add(R.id.frag_myfocus,frag04);
        transaction.show(frag01).hide(frag02).hide(frag03).hide(frag04);
        transaction.commit();



        RadioGroup rg_focus = findViewById(R.id.rg_focus);
        rg_focus.check(R.id.a11);
        rg_focus.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                FragmentTransaction transaction1 = manager.beginTransaction();
                switch (checkedId){
                    case R.id.a11:
                        transaction1.show(frag01).hide(frag02).hide(frag03).hide(frag04);
                        break;
                    case R.id.you:
                        transaction1.show(frag02).hide(frag01).hide(frag04).hide(frag03);
                        break;
                    case R.id.dai:
                        transaction1.show(frag03).hide(frag01).hide(frag02).hide(frag04);
                        break;
                    case R.id.zhe:
                        transaction1.show(frag04).hide(frag01).hide(frag02).hide(frag03);
                        break;
                }
                transaction1.commit();
            }
        });

    }
}
