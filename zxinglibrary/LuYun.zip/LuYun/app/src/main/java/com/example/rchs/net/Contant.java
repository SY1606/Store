package com.example.rchs.net;

public class Contant {
    public static final String Re = "http://wxapi.luyunkeji.com";
}
