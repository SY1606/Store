package com.example.rchs.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;
import com.example.rchs.view.adapter.KeyboardUtil;
import com.example.rchs.view.adapter.MyKeyBoardView;

public class SacnActivity extends AppCompatActivity {

    private EditText jine;
    private KeyboardUtil keyboardUtil;
    private MyKeyBoardView keyboard_view;
    private TextView you;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sacn);

        keyboardUtil = new KeyboardUtil(this, true);
        keyboard_view = findViewById(R.id.keyboard_view);
        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(SacnActivity.this, true);
        StatusBarUtil.setTranslucentStatus(SacnActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(SacnActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(SacnActivity.this, 0x55000000);
        }
        you = findViewById(R.id.you);
        you.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (jine.getText().toString().equals("")){
                    Toast.makeText(SacnActivity.this,"请输入收款金额",Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(SacnActivity.this,Scan_hActivity.class);
                    startActivity(intent);
                }
            }
        });

        jine = findViewById(R.id.jine);
        jine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                keyboardUtil.attachTo(jine);
            }
        });



        keyboardUtil.setOnOkClick(new KeyboardUtil.OnOkClick() {
            @Override
            public void onOkClick() {
                if (jine.getText().toString().equals("")){
                    Toast.makeText(SacnActivity.this,"请输入收款金额",Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(SacnActivity.this,Scan_hActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
