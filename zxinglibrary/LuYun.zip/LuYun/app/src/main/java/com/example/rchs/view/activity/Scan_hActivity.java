package com.example.rchs.view.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.rchs.R;
import com.example.rchs.net.StatusBarUtil;
import com.example.rchs.view.adapter.KeyboardUtil;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class Scan_hActivity extends AppCompatActivity {

    @BindView(R.id.sao)
    Button sao;
    @BindView(R.id.money)
    EditText money;
    @BindView(R.id.view9)
    View view9;
    @BindView(R.id.hexiao)
    EditText hexiao;
    @BindView(R.id.view10)
    View view10;
    private KeyboardUtil keyboardUtil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_h);
        ButterKnife.bind(this);

        //沉浸式状态栏
        StatusBarUtil.setRootViewFitsSystemWindows(Scan_hActivity.this,true);
        StatusBarUtil.setTranslucentStatus(Scan_hActivity.this);
        if (!StatusBarUtil.setStatusBarDarkTheme(Scan_hActivity.this, true)) {
            StatusBarUtil.setStatusBarColor(Scan_hActivity.this,0x55000000);
        }

        keyboardUtil = new KeyboardUtil(this, true);
    }

    @OnClick({R.id.money, R.id.hexiao})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.money:
                break;
            case R.id.hexiao:
                keyboardUtil.attachTo(hexiao);
                break;

        }

        keyboardUtil.setOnOkClick(new KeyboardUtil.OnOkClick() {
            @Override
            public void onOkClick() {
                if (hexiao.getText().toString().equals("")){
                    Toast.makeText(Scan_hActivity.this,"请输入收款金额",Toast.LENGTH_SHORT).show();
                }else {
                    //Intent intent = new Intent(Scan_hActivity.this,Scan_hActivity.class);
                    //startActivity(intent);
                }
            }
        });

        //扫码
        sao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //判断相机权限是打开
//0代表打开权限,-1代表没有打开权限
                if(ActivityCompat.checkSelfPermission(Scan_hActivity.this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
//如果没有打开权限（-1），就去获取相机打开权限
                    ActivityCompat.requestPermissions(Scan_hActivity.this,new String[]{Manifest.permission.CAMERA},100);
                }
                else
                {
//如果已经打开权限则直接执行扫描二维码
                    IntentIntegrator integrator = new IntentIntegrator(Scan_hActivity.this);
                    integrator.initiateScan();
                }
            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 100)
        {
            //权限下标判断     权限打开
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(Scan_hActivity.this,"权限已经打开",Toast.LENGTH_SHORT).show();
            }
            //没有打开权限则直接关闭
            else
            {
                Scan_hActivity.this.finish();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(intentResult != null) {
            String contents = intentResult.getContents();
            //变量contents就是二维码解码后的信息
            Toast.makeText(Scan_hActivity.this, "扫码成功得到数据" + contents, Toast.LENGTH_SHORT).show();
        }

    }
}
