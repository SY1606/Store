package com.example.rchs.di.presenter;
import com.example.rchs.di.contract.DatasContract;
import com.example.rchs.di.model.DatasModel;

import java.lang.ref.SoftReference;

import okhttp3.MultipartBody;

public class DatasPresenter implements DatasContract.DatasPresenter<DatasContract.DatasView> {

    DatasContract.DatasModel datasModel;
    DatasContract.DatasView datasView;
    private SoftReference<DatasContract.DatasView> softReference;

    @Override
    public void attachView(DatasContract.DatasView datasView) {
        this.datasView = datasView;
        softReference = new SoftReference<>(datasView);
        datasModel = new DatasModel();
    }

    @Override
    public void detachView(DatasContract.DatasView datasView) {
        softReference.clear();
    }

    @Override
    public void requestPhotoData(MultipartBody.Part image) {
        datasModel.reponsePhotoData(image, new DatasContract.DatasModel.CallBack() {
            @Override
            public void onCallBack(String message) {
                datasView.showPhotoData(message);
            }
        });
    }
}
